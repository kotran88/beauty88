export interface Reservation{
    name:string;
    time:string;
}